<?php
//Delete Cookie
unset($_COOKIE[idreferal]);

?>